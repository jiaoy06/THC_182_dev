﻿使用方法：
1. 将“东方决斗乡THC”快捷方式，复制粘贴为“东方决斗乡THC_thmugen”快捷方式
2. 右键打开“东方决斗乡THC_thmugen”快捷方式，在“快捷方式-目标”的最后，加上“ -ethmugen.cdb”